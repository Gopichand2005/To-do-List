import React, { useState } from 'react';
import { TodoProvider } from './context/TodoContext';
import { ThemeProvider } from './context/ThemeContext';
import Header from './components/Header';
import TodoForm from './components/TodoForm';
import TodoFilters from './components/TodoFilters';
import TodoList from './components/TodoList';
import CategoryManager from './components/CategoryManager';
import { Settings } from 'lucide-react';

function App() {
  const [showCategories, setShowCategories] = useState(false);

  return (
    <ThemeProvider>
      <TodoProvider>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
          <div className="container mx-auto px-4 py-8 max-w-3xl">
            <Header />
            
            <main className="mt-8">
              <TodoForm />
              
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                  My Tasks
                </h2>
                <button
                  onClick={() => setShowCategories(!showCategories)}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-indigo-600 dark:text-indigo-400 
                    hover:text-indigo-800 dark:hover:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-gray-800 
                    rounded-lg transition-colors duration-200"
                >
                  <Settings size={18} />
                  {showCategories ? 'Hide' : 'Manage'} Categories
                </button>
              </div>
              
              {showCategories && <CategoryManager />}
              
              <TodoFilters />
              <TodoList />
            </main>
            
            <footer className="mt-16 text-center text-sm text-gray-500 dark:text-gray-400">
              <p>TaskMaster © {new Date().getFullYear()} - Your tasks, simplified.</p>
            </footer>
          </div>
        </div>
      </TodoProvider>
    </ThemeProvider>
  );
}

export default App;