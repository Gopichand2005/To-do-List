import React, { useState } from 'react';
import { Todo, Category } from '../types';
import { Check, Trash2, Edit, X, Save } from 'lucide-react';

interface TodoItemProps {
  todo: Todo;
  categories: Category[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, updates: Partial<Todo>) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({
  todo,
  categories,
  onToggle,
  onDelete,
  onEdit,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(todo.title);
  const [editedDescription, setEditedDescription] = useState(todo.description || '');
  const [editedCategory, setEditedCategory] = useState(todo.category);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const handleSave = () => {
    if (editedTitle.trim()) {
      onEdit(todo.id, {
        title: editedTitle,
        description: editedDescription || undefined,
        category: editedCategory,
      });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedTitle(todo.title);
    setEditedDescription(todo.description || '');
    setEditedCategory(todo.category);
    setIsEditing(false);
  };

  const category = categories.find((c) => c.id === todo.category);
  const categoryColor = category?.color || '#6B7280';

  return (
    <div
      className={`group p-4 mb-3 rounded-lg transition-all duration-300 hover:shadow-md
        ${todo.completed ? 'bg-gray-100 dark:bg-gray-800 opacity-75' : 'bg-white dark:bg-gray-700'}
        border border-gray-200 dark:border-gray-600`}
    >
      {isEditing ? (
        <div className="space-y-3">
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 
              focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:text-white"
            placeholder="Task title"
            autoFocus
          />
          <textarea
            value={editedDescription}
            onChange={(e) => setEditedDescription(e.target.value)}
            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 
              focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:text-white"
            placeholder="Description (optional)"
            rows={2}
          />
          <select
            value={editedCategory}
            onChange={(e) => setEditedCategory(e.target.value)}
            className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 
              focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:text-white"
          >
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          <div className="flex justify-end space-x-2 mt-2">
            <button
              onClick={handleCancel}
              className="flex items-center p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              <X size={16} className="mr-1" /> Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex items-center p-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              <Save size={16} className="mr-1" /> Save
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-start">
            <button
              onClick={() => onToggle(todo.id)}
              className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center
                ${
                  todo.completed
                    ? 'border-emerald-500 bg-emerald-500 text-white'
                    : 'border-gray-300 dark:border-gray-500 hover:border-indigo-500 dark:hover:border-indigo-400'
                }`}
            >
              {todo.completed && <Check size={14} />}
            </button>
            <div className="ml-3 flex-1">
              <div className="flex items-center">
                <h3
                  className={`text-lg font-medium
                    ${
                      todo.completed
                        ? 'line-through text-gray-500 dark:text-gray-400'
                        : 'text-gray-900 dark:text-white'
                    }`}
                >
                  {todo.title}
                </h3>
                <div
                  className="ml-2 px-2 py-0.5 text-xs rounded-full text-white"
                  style={{ backgroundColor: categoryColor }}
                >
                  {category?.name}
                </div>
              </div>
              {todo.description && (
                <p
                  className={`mt-1 text-sm
                    ${
                      todo.completed
                        ? 'text-gray-400 dark:text-gray-500'
                        : 'text-gray-600 dark:text-gray-300'
                    }`}
                >
                  {todo.description}
                </p>
              )}
              <p className="mt-1 text-xs text-gray-400 dark:text-gray-500">
                {new Date(todo.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="flex justify-end mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {showConfirmDelete ? (
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600 dark:text-gray-400">Confirm delete?</span>
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                >
                  <X size={16} />
                </button>
                <button
                  onClick={() => onDelete(todo.id)}
                  className="p-1 text-red-500 hover:text-red-700"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ) : (
              <div className="flex space-x-2">
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-1 text-indigo-500 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300"
                >
                  <Edit size={16} />
                </button>
                <button
                  onClick={() => setShowConfirmDelete(true)}
                  className="p-1 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default TodoItem;