import React, { useState } from 'react';
import { useTodo } from '../context/TodoContext';
import { Plus, Calendar, AlignLeft, Tag } from 'lucide-react';

const TodoForm: React.FC = () => {
  const { addTodo, categories } = useTodo();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState(categories[0]?.id || '');
  const [isExpanded, setIsExpanded] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      addTodo({
        title: title.trim(),
        description: description.trim() || undefined,
        completed: false,
        category,
      });
      setTitle('');
      setDescription('');
      setIsExpanded(false);
    }
  };

  return (
    <form 
      onSubmit={handleSubmit}
      className="mb-8 p-6 bg-white dark:bg-gray-700 rounded-xl shadow-lg border border-gray-200 dark:border-gray-600 transition-all duration-300"
    >
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onFocus={() => setIsExpanded(true)}
            placeholder="What needs to be done?"
            className="w-full pl-4 pr-12 py-3 text-lg text-gray-900 dark:text-white bg-transparent border-2 border-gray-200 dark:border-gray-600 rounded-lg focus:border-indigo-500 dark:focus:border-indigo-400 focus:outline-none transition-colors"
            required
          />
          <Plus 
            size={20} 
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"
          />
        </div>
        <button
          type="submit"
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center gap-2"
        >
          <Plus size={20} />
          Add Task
        </button>
      </div>

      {isExpanded && (
        <div className="mt-4 space-y-4 animate-fadeIn">
          <div className="flex items-start gap-3">
            <AlignLeft size={20} className="mt-2 text-gray-400" />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description..."
              className="flex-1 p-3 rounded-lg border-2 border-gray-200 dark:border-gray-600 
                bg-transparent text-gray-900 dark:text-white
                focus:border-indigo-500 dark:focus:border-indigo-400 focus:outline-none
                min-h-[100px] resize-none"
            />
          </div>
          <div className="flex items-center gap-3">
            <Tag size={20} className="text-gray-400" />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="flex-1 p-3 rounded-lg border-2 border-gray-200 dark:border-gray-600 
                bg-transparent text-gray-900 dark:text-white
                focus:border-indigo-500 dark:focus:border-indigo-400 focus:outline-none"
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}
    </form>
  );
};

export default TodoForm;