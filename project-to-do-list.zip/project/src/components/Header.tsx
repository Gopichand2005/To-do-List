import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { CheckSquare, Moon, Sun } from 'lucide-react';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="py-4 mb-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <CheckSquare className="h-7 w-7 text-indigo-600 dark:text-indigo-400" />
          <h1 className="ml-2 text-2xl font-bold text-gray-900 dark:text-white">TaskMaster</h1>
        </div>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? (
            <Sun className="h-5 w-5 text-yellow-400" />
          ) : (
            <Moon className="h-5 w-5 text-indigo-600" />
          )}
        </button>
      </div>
    </header>
  );
};

export default Header;