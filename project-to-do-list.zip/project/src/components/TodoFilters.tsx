import React from 'react';
import { useTodo } from '../context/TodoContext';
import { FilterStatus } from '../types';
import { CheckCheck, Circle, ListFilter } from 'lucide-react';

const TodoFilters: React.FC = () => {
  const { 
    filterStatus, 
    setFilterStatus, 
    filterCategory, 
    setFilterCategory, 
    categories 
  } = useTodo();

  const handleStatusChange = (status: FilterStatus) => {
    setFilterStatus(status);
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilterCategory(e.target.value);
  };

  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3 sm:gap-0">
      <div className="flex space-x-1">
        <button
          onClick={() => handleStatusChange('all')}
          className={`px-3 py-1.5 rounded-l-lg transition-colors text-sm font-medium
            ${
              filterStatus === 'all'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
            }`}
        >
          <ListFilter size={16} className="inline mr-1" /> All
        </button>
        <button
          onClick={() => handleStatusChange('active')}
          className={`px-3 py-1.5 transition-colors text-sm font-medium
            ${
              filterStatus === 'active'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
            }`}
        >
          <Circle size={16} className="inline mr-1" /> Active
        </button>
        <button
          onClick={() => handleStatusChange('completed')}
          className={`px-3 py-1.5 rounded-r-lg transition-colors text-sm font-medium
            ${
              filterStatus === 'completed'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
            }`}
        >
          <CheckCheck size={16} className="inline mr-1" /> Completed
        </button>
      </div>

      <div>
        <select
          value={filterCategory}
          onChange={handleCategoryChange}
          className="px-3 py-1.5 rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300 
            border-none focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
        >
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default TodoFilters;