import React, { useState } from 'react';
import { useTodo } from '../context/TodoContext';
import { Category } from '../types';
import { Plus, X, Edit, Save, Trash2 } from 'lucide-react';

const CategoryManager: React.FC = () => {
  const { categories, addCategory, deleteCategory } = useTodo();
  const [isAdding, setIsAdding] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState('#4F46E5');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('');

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      addCategory({
        name: newCategoryName.trim(),
        color: newCategoryColor,
      });
      setNewCategoryName('');
      setNewCategoryColor('#4F46E5');
      setIsAdding(false);
    }
  };

  const startEditing = (category: Category) => {
    setEditingId(category.id);
    setEditName(category.name);
    setEditColor(category.color);
  };

  const cancelEditing = () => {
    setEditingId(null);
  };

  const predefinedColors = [
    '#4F46E5', // Indigo
    '#10B981', // Emerald
    '#F59E0B', // Amber
    '#EF4444', // Red
    '#8B5CF6', // Purple
    '#EC4899', // Pink
    '#06B6D4', // Cyan
    '#84CC16', // Lime
  ];

  return (
    <div className="mt-8 p-4 bg-white dark:bg-gray-700 rounded-lg shadow border border-gray-200 dark:border-gray-600">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Categories</h3>
      
      <div className="space-y-3">
        {categories.map((category) => (
          <div 
            key={category.id}
            className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600"
          >
            {editingId === category.id ? (
              <>
                <div className="flex items-center flex-1">
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="flex-1 p-1 mr-2 rounded border border-gray-300 dark:border-gray-600 
                      focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:text-white"
                  />
                  <input
                    type="color"
                    value={editColor}
                    onChange={(e) => setEditColor(e.target.value)}
                    className="w-8 h-8 rounded border-0 p-0 bg-transparent"
                  />
                </div>
                <div className="flex space-x-1 ml-2">
                  <button
                    onClick={cancelEditing}
                    className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                  >
                    <X size={16} />
                  </button>
                  <button
                    onClick={() => {
                      // Handle save edit
                      cancelEditing();
                    }}
                    className="p-1 text-indigo-500 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300"
                  >
                    <Save size={16} />
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center">
                  <div
                    className="w-4 h-4 rounded-full mr-2"
                    style={{ backgroundColor: category.color }}
                  ></div>
                  <span className="text-gray-800 dark:text-gray-200">{category.name}</span>
                </div>
                <div className="flex space-x-1">
                  <button
                    onClick={() => startEditing(category)}
                    className="p-1 text-indigo-500 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => deleteCategory(category.id)}
                    className="p-1 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                    disabled={categories.length <= 1}
                  >
                    <Trash2 size={16} className={categories.length <= 1 ? 'opacity-50' : ''} />
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {isAdding ? (
        <div className="mt-3 p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
          <div className="flex items-center mb-2">
            <input
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="Category name"
              className="flex-1 p-2 rounded border border-gray-300 dark:border-gray-600 
                focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:text-white"
            />
            <div className="ml-2 flex items-center">
              <input
                type="color"
                value={newCategoryColor}
                onChange={(e) => setNewCategoryColor(e.target.value)}
                className="w-8 h-8 rounded border-0 p-0 bg-transparent"
              />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-3">
            {predefinedColors.map((color) => (
              <button
                key={color}
                onClick={() => setNewCategoryColor(color)}
                className={`w-6 h-6 rounded-full border ${
                  newCategoryColor === color ? 'ring-2 ring-offset-2 ring-gray-400' : ''
                }`}
                style={{ backgroundColor: color }}
                aria-label={`Select color ${color}`}
              ></button>
            ))}
          </div>
          
          <div className="flex justify-end space-x-2">
            <button
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleAddCategory}
              className="px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              Add
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsAdding(true)}
          className="mt-3 flex items-center px-3 py-2 text-sm text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300"
        >
          <Plus size={16} className="mr-1" /> Add New Category
        </button>
      )}
    </div>
  );
};

export default CategoryManager;