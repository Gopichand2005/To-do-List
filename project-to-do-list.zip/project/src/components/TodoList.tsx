import React, { useMemo } from 'react';
import { useTodo } from '../context/TodoContext';
import TodoItem from './TodoItem';
import { ClipboardList, ListFilter } from 'lucide-react';

const TodoList: React.FC = () => {
  const { 
    todos, 
    categories, 
    toggleTodo, 
    deleteTodo, 
    editTodo,
    filterStatus,
    filterCategory
  } = useTodo();

  const filteredTodos = useMemo(() => {
    return todos.filter((todo) => {
      if (filterStatus === 'active' && todo.completed) return false;
      if (filterStatus === 'completed' && !todo.completed) return false;
      if (filterCategory && todo.category !== filterCategory) return false;
      return true;
    });
  }, [todos, filterStatus, filterCategory]);

  if (todos.length === 0) {
    return (
      <div className="text-center py-16 bg-white dark:bg-gray-700 rounded-xl shadow-lg border border-gray-200 dark:border-gray-600">
        <ClipboardList className="mx-auto h-20 w-20 text-indigo-400 dark:text-indigo-500" />
        <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">No tasks yet</h3>
        <p className="mt-2 text-gray-600 dark:text-gray-400">Start by adding your first task above!</p>
      </div>
    );
  }

  if (filteredTodos.length === 0) {
    return (
      <div className="text-center py-16 bg-white dark:bg-gray-700 rounded-xl shadow-lg border border-gray-200 dark:border-gray-600">
        <ListFilter className="mx-auto h-20 w-20 text-gray-400 dark:text-gray-500" />
        <h3 className="mt-4 text-xl font-semibold text-gray-900 dark:text-white">No matching tasks</h3>
        <p className="mt-2 text-gray-600 dark:text-gray-400">Try adjusting your filters to see more tasks.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-fadeIn">
      {filteredTodos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          categories={categories}
          onToggle={toggleTodo}
          onDelete={deleteTodo}
          onEdit={editTodo}
        />
      ))}
      <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
        {filteredTodos.length} {filteredTodos.length === 1 ? 'task' : 'tasks'} shown
      </div>
    </div>
  );
};

export default TodoList;