import React, { createContext, useContext, useState, useEffect } from 'react';
import { Todo, Category, FilterStatus } from '../types';

interface TodoContextType {
  todos: Todo[];
  categories: Category[];
  filterStatus: FilterStatus;
  filterCategory: string;
  addTodo: (todo: Omit<Todo, 'id' | 'createdAt'>) => void;
  toggleTodo: (id: string) => void;
  deleteTodo: (id: string) => void;
  editTodo: (id: string, updates: Partial<Todo>) => void;
  reorderTodos: (startIndex: number, endIndex: number) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: string) => void;
  setFilterStatus: (status: FilterStatus) => void;
  setFilterCategory: (categoryId: string) => void;
}

const TodoContext = createContext<TodoContextType | undefined>(undefined);

const defaultCategories: Category[] = [
  { id: '1', name: 'Personal', color: '#4F46E5' },
  { id: '2', name: 'Work', color: '#10B981' },
  { id: '3', name: 'Shopping', color: '#F59E0B' },
];

export const TodoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [todos, setTodos] = useState<Todo[]>(() => {
    const storedTodos = localStorage.getItem('todos');
    return storedTodos ? JSON.parse(storedTodos) : [];
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const storedCategories = localStorage.getItem('categories');
    return storedCategories ? JSON.parse(storedCategories) : defaultCategories;
  });

  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');
  const [filterCategory, setFilterCategory] = useState<string>('');

  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  useEffect(() => {
    localStorage.setItem('categories', JSON.stringify(categories));
  }, [categories]);

  const addTodo = (todo: Omit<Todo, 'id' | 'createdAt'>) => {
    const newTodo: Todo = {
      ...todo,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
    };
    setTodos((prevTodos) => [newTodo, ...prevTodos]);
  };

  const toggleTodo = (id: string) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id: string) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  const editTodo = (id: string, updates: Partial<Todo>) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === id ? { ...todo, ...updates } : todo
      )
    );
  };

  const reorderTodos = (startIndex: number, endIndex: number) => {
    const result = Array.from(todos);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    setTodos(result);
  };

  const addCategory = (category: Omit<Category, 'id'>) => {
    const newCategory: Category = {
      ...category,
      id: crypto.randomUUID(),
    };
    setCategories((prevCategories) => [...prevCategories, newCategory]);
  };

  const deleteCategory = (id: string) => {
    setCategories((prevCategories) => 
      prevCategories.filter((category) => category.id !== id)
    );
    // Reset todos with deleted category to the first available category or empty string
    setTodos((prevTodos) => 
      prevTodos.map((todo) => 
        todo.category === id 
          ? { ...todo, category: categories[0]?.id || '' } 
          : todo
      )
    );
  };

  return (
    <TodoContext.Provider
      value={{
        todos,
        categories,
        filterStatus,
        filterCategory,
        addTodo,
        toggleTodo,
        deleteTodo,
        editTodo,
        reorderTodos,
        addCategory,
        deleteCategory,
        setFilterStatus,
        setFilterCategory,
      }}
    >
      {children}
    </TodoContext.Provider>
  );
};

export const useTodo = (): TodoContextType => {
  const context = useContext(TodoContext);
  if (context === undefined) {
    throw new Error('useTodo must be used within a TodoProvider');
  }
  return context;
};