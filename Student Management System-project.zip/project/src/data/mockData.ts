import { Student, Course, Grade, Attendance, User, Notification, Enrollment } from '../types';

export const students: Student[] = [
  {
    id: '1',
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    dateOfBirth: '2005-05-15',
    gender: 'male',
    address: '123 Main St, Anytown, CA 90210',
    phoneNumber: '555-123-4567',
    enrollmentDate: '2023-09-01',
    profileImage: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '2',
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane.smith@example.com',
    dateOfBirth: '2004-11-23',
    gender: 'female',
    address: '456 Oak Ave, Springfield, IL 62704',
    phoneNumber: '555-987-6543',
    enrollmentDate: '2023-09-01',
    profileImage: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '3',
    firstName: 'Michael',
    lastName: 'Johnson',
    email: 'michael.johnson@example.com',
    dateOfBirth: '2005-03-08',
    gender: 'male',
    address: '789 Pine St, Metropolis, NY 10001',
    phoneNumber: '555-456-7890',
    enrollmentDate: '2023-09-01',
    profileImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '4',
    firstName: 'Emily',
    lastName: 'Williams',
    email: 'emily.williams@example.com',
    dateOfBirth: '2004-07-12',
    gender: 'female',
    address: '321 Elm St, Riverdale, CA 90210',
    phoneNumber: '555-234-5678',
    enrollmentDate: '2023-09-01',
    profileImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '5',
    firstName: 'David',
    lastName: 'Brown',
    email: 'david.brown@example.com',
    dateOfBirth: '2005-01-30',
    gender: 'male',
    address: '654 Maple Ave, Liberty, TX 77575',
    phoneNumber: '555-876-5432',
    enrollmentDate: '2023-09-01',
    profileImage: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150'
  }
];

export const courses: Course[] = [
  {
    id: '1',
    name: 'Advanced Mathematics',
    code: 'MATH401',
    description: 'Advanced mathematical concepts including calculus and statistics',
    credits: 4,
    instructor: 'Dr. Alan Thompson',
    schedule: 'MWF 9:00 - 10:30 AM'
  },
  {
    id: '2',
    name: 'Physics Fundamentals',
    code: 'PHYS101',
    description: 'Introduction to basic physics principles',
    credits: 3,
    instructor: 'Prof. Sarah Chen',
    schedule: 'TTh 11:00 AM - 12:30 PM'
  },
  {
    id: '3',
    name: 'English Literature',
    code: 'ENG202',
    description: 'Analysis of classic and contemporary literature',
    credits: 3,
    instructor: 'Dr. Michael Stevens',
    schedule: 'MWF 1:00 - 2:30 PM'
  },
  {
    id: '4',
    name: 'Computer Science',
    code: 'CS101',
    description: 'Introduction to programming and algorithms',
    credits: 4,
    instructor: 'Prof. Jennifer Davis',
    schedule: 'TTh 3:00 - 4:30 PM'
  },
  {
    id: '5',
    name: 'Biology',
    code: 'BIO201',
    description: 'Study of living organisms and their interactions',
    credits: 4,
    instructor: 'Dr. Robert Johnson',
    schedule: 'MWF 10:30 AM - 12:00 PM'
  }
];

export const grades: Grade[] = [
  { id: '1', studentId: '1', courseId: '1', assignment: 'Midterm Exam', score: 85, maxScore: 100, date: '2023-10-15' },
  { id: '2', studentId: '1', courseId: '2', assignment: 'Lab Report 1', score: 92, maxScore: 100, date: '2023-09-20' },
  { id: '3', studentId: '2', courseId: '1', assignment: 'Midterm Exam', score: 78, maxScore: 100, date: '2023-10-15' },
  { id: '4', studentId: '2', courseId: '3', assignment: 'Essay Analysis', score: 88, maxScore: 100, date: '2023-10-05' },
  { id: '5', studentId: '3', courseId: '4', assignment: 'Programming Project', score: 95, maxScore: 100, date: '2023-10-10' },
  { id: '6', studentId: '3', courseId: '5', assignment: 'Lab Experiment', score: 90, maxScore: 100, date: '2023-09-25' },
  { id: '7', studentId: '4', courseId: '3', assignment: 'Essay Analysis', score: 91, maxScore: 100, date: '2023-10-05' },
  { id: '8', studentId: '4', courseId: '5', assignment: 'Lab Experiment', score: 84, maxScore: 100, date: '2023-09-25' },
  { id: '9', studentId: '5', courseId: '2', assignment: 'Lab Report 1', score: 79, maxScore: 100, date: '2023-09-20' },
  { id: '10', studentId: '5', courseId: '4', assignment: 'Programming Project', score: 82, maxScore: 100, date: '2023-10-10' }
];

export const attendance: Attendance[] = [
  { id: '1', studentId: '1', courseId: '1', date: '2023-09-05', status: 'present' },
  { id: '2', studentId: '1', courseId: '1', date: '2023-09-07', status: 'present' },
  { id: '3', studentId: '1', courseId: '1', date: '2023-09-12', status: 'late' },
  { id: '4', studentId: '1', courseId: '1', date: '2023-09-14', status: 'absent' },
  { id: '5', studentId: '2', courseId: '3', date: '2023-09-04', status: 'present' },
  { id: '6', studentId: '2', courseId: '3', date: '2023-09-06', status: 'present' },
  { id: '7', studentId: '2', courseId: '3', date: '2023-09-11', status: 'present' },
  { id: '8', studentId: '2', courseId: '3', date: '2023-09-13', status: 'excused' },
  { id: '9', studentId: '3', courseId: '5', date: '2023-09-05', status: 'present' },
  { id: '10', studentId: '3', courseId: '5', date: '2023-09-07', status: 'absent' }
];

export const enrollments: Enrollment[] = [
  { id: '1', studentId: '1', courseId: '1', enrollmentDate: '2023-08-25', status: 'active' },
  { id: '2', studentId: '1', courseId: '2', enrollmentDate: '2023-08-25', status: 'active' },
  { id: '3', studentId: '2', courseId: '1', enrollmentDate: '2023-08-26', status: 'active' },
  { id: '4', studentId: '2', courseId: '3', enrollmentDate: '2023-08-26', status: 'active' },
  { id: '5', studentId: '3', courseId: '4', enrollmentDate: '2023-08-24', status: 'active' },
  { id: '6', studentId: '3', courseId: '5', enrollmentDate: '2023-08-24', status: 'active' },
  { id: '7', studentId: '4', courseId: '3', enrollmentDate: '2023-08-25', status: 'active' },
  { id: '8', studentId: '4', courseId: '5', enrollmentDate: '2023-08-25', status: 'active' },
  { id: '9', studentId: '5', courseId: '2', enrollmentDate: '2023-08-23', status: 'active' },
  { id: '10', studentId: '5', courseId: '4', enrollmentDate: '2023-08-23', status: 'active' }
];

export const users: User[] = [
  { id: '1', username: 'admin', email: 'admin@school.edu', role: 'admin', firstName: 'Admin', lastName: 'User' },
  { id: '2', username: 'thompson', email: 'alan.thompson@school.edu', role: 'teacher', firstName: 'Alan', lastName: 'Thompson' },
  { id: '3', username: 'chen', email: 'sarah.chen@school.edu', role: 'teacher', firstName: 'Sarah', lastName: 'Chen' },
  { id: '4', username: 'jdoe', email: 'john.doe@example.com', role: 'student', firstName: 'John', lastName: 'Doe' },
  { id: '5', username: 'jsmith', email: 'jane.smith@example.com', role: 'student', firstName: 'Jane', lastName: 'Smith' }
];

export const notifications: Notification[] = [
  { id: '1', title: 'New Assignment Posted', message: 'A new assignment has been posted for Physics Fundamentals', date: '2023-10-18', read: false, type: 'info' },
  { id: '2', title: 'Upcoming Exam', message: 'Reminder: Advanced Mathematics midterm exam on Friday', date: '2023-10-17', read: true, type: 'warning' },
  { id: '3', title: 'Grade Posted', message: 'Your grade for Computer Science programming project has been posted', date: '2023-10-16', read: false, type: 'success', recipientId: '3' },
  { id: '4', title: 'Attendance Warning', message: 'You have missed more than two classes in Advanced Mathematics', date: '2023-10-15', read: false, type: 'error', recipientId: '1' },
  { id: '5', title: 'School Event', message: 'Annual Science Fair next Thursday in the main auditorium', date: '2023-10-14', read: true, type: 'info' }
];