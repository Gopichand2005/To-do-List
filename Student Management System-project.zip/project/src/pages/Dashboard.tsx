import React from 'react';
import { Users, BookOpen, GraduationCap, Calendar } from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import RecentActivity from '../components/dashboard/RecentActivity';
import AttendanceChart from '../components/dashboard/AttendanceChart';
import GradeDistribution from '../components/dashboard/GradeDistribution';
import { students, courses, grades, attendance } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  // Calculate some statistics
  const totalStudents = students.length;
  const totalCourses = courses.length;
  const averageGrade = grades.reduce((sum, grade) => sum + (grade.score / grade.maxScore) * 100, 0) / grades.length;
  const attendanceRate = attendance.filter(a => a.status === 'present').length / attendance.length * 100;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.firstName}!</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Students"
          value={totalStudents}
          icon={<Users className="h-6 w-6 text-blue-700" />}
          change={{ value: 12, isPositive: true }}
        />
        
        <StatCard
          title="Total Courses"
          value={totalCourses}
          icon={<BookOpen className="h-6 w-6 text-green-700" />}
        />
        
        <StatCard
          title="Average Grade"
          value={`${Math.round(averageGrade)}%`}
          icon={<GraduationCap className="h-6 w-6 text-amber-700" />}
          change={{ value: 5, isPositive: true }}
        />
        
        <StatCard
          title="Attendance Rate"
          value={`${Math.round(attendanceRate)}%`}
          icon={<Calendar className="h-6 w-6 text-red-700" />}
          change={{ value: 2, isPositive: false }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <RecentActivity />
        </div>
        
        <div className="lg:col-span-1">
          <AttendanceChart />
        </div>
        
        <div className="lg:col-span-1">
          <GradeDistribution />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;