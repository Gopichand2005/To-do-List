import React, { useState } from 'react';
import { Search, Filter, Plus, MoreHorizontal, Edit, Trash2, EyeIcon } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Badge from '../components/ui/Badge';
import AddStudentDialog from '../components/students/AddStudentDialog';
import { Student, Enrollment, Grade } from '../types';
import { students, enrollments, courses, grades } from '../data/mockData';

const Students: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterOpen, setFilterOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Filter students based on search term
  const filteredStudents = students.filter(student => 
    student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get enrolled courses for a student
  const getEnrolledCourses = (studentId: string) => {
    const studentEnrollments = enrollments.filter(e => e.studentId === studentId);
    return studentEnrollments.map(e => {
      const course = courses.find(c => c.id === e.courseId);
      return course ? course.name : 'Unknown Course';
    });
  };

  // Calculate average grade for a student
  const getAverageGrade = (studentId: string) => {
    const studentGrades = grades.filter((g: Grade) => g.studentId === studentId);
    if (studentGrades.length === 0) return 'N/A';
    
    const average = studentGrades.reduce((sum, grade) => 
      sum + (grade.score / grade.maxScore) * 100, 0) / studentGrades.length;
    
    return `${Math.round(average)}%`;
  };

  // Determine grade status color
  const getGradeStatusColor = (gradeStr: string) => {
    if (gradeStr === 'N/A') return 'default';
    
    const grade = parseInt(gradeStr);
    if (grade >= 90) return 'success';
    if (grade >= 70) return 'info';
    if (grade >= 60) return 'warning';
    return 'danger';
  };

  const handleAddStudent = async (studentData: any) => {
    // In a real app, this would make an API call
    console.log('Adding student:', studentData);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Students</h1>
          <p className="text-gray-600">Manage and view student information</p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Button onClick={() => setIsAddDialogOpen(true)} leftIcon={<Plus className="h-4 w-4" />}>
            Add Student
          </Button>
        </div>
      </div>
      
      <Card>
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="Search students..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              fullWidth
            />
          </div>
          
          <div>
            <Button
              variant="outline"
              onClick={() => setFilterOpen(!filterOpen)}
              leftIcon={<Filter className="h-4 w-4" />}
            >
              Filter
            </Button>
          </div>
        </div>
        
        {filterOpen && (
          <div className="mb-6 p-4 bg-gray-50 rounded-md border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input label="Grade Level" placeholder="Select grade level" />
              <Input label="Enrollment Date" type="date" />
              <Input label="Status" placeholder="Select status" />
            </div>
          </div>
        )}
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Courses
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Avg. Grade
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Enrollment Date
                </th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredStudents.map((student: Student) => (
                <tr key={student.id} className="hover:bg-gray-50 transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {student.profileImage ? (
                        <img className="h-10 w-10 rounded-full object-cover" src={student.profileImage} alt="" />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-medium">
                          {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                        </div>
                      )}
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{student.firstName} {student.lastName}</div>
                        <div className="text-sm text-gray-500">ID: {student.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{student.email}</div>
                    <div className="text-sm text-gray-500">{student.phoneNumber}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {getEnrolledCourses(student.id).slice(0, 2).map((course, index) => (
                        <Badge key={index} variant="info" className="whitespace-nowrap">
                          {course}
                        </Badge>
                      ))}
                      {getEnrolledCourses(student.id).length > 2 && (
                        <Badge variant="default">
                          +{getEnrolledCourses(student.id).length - 2} more
                        </Badge>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge variant={getGradeStatusColor(getAverageGrade(student.id))}>
                      {getAverageGrade(student.id)}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(student.enrollmentDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="relative group inline-block">
                      <button className="text-gray-500 hover:text-gray-700 focus:outline-none">
                        <MoreHorizontal className="h-5 w-5" />
                      </button>
                      <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                        <button className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                          <EyeIcon className="h-4 w-4 mr-2" />
                          View Details
                        </button>
                        <button className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </button>
                        <button className="flex w-full items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredStudents.length === 0 && (
          <div className="text-center py-6">
            <p className="text-gray-500">No students found matching your search criteria.</p>
          </div>
        )}
        
        <div className="flex items-center justify-between mt-6">
          <div className="text-sm text-gray-500">
            Showing <span className="font-medium">{filteredStudents.length}</span> of <span className="font-medium">{students.length}</span> students
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" disabled>
              Next
            </Button>
          </div>
        </div>
      </Card>

      <AddStudentDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onSubmit={handleAddStudent}
      />
    </div>
  );
};

export default Students;