import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { GraduationCap } from 'lucide-react';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const success = await login(username, password);
      if (!success) {
        setError('Invalid username or password');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-md">
        <div className="text-center">
          <div className="flex justify-center">
            <div className="p-2 bg-blue-800 rounded-full">
              <GraduationCap className="h-10 w-10 text-white" />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Student Management System</h2>
          <p className="mt-2 text-sm text-gray-600">Sign in to your account</p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}
          
          <div className="rounded-md -space-y-px">
            <Input
              label="Username"
              id="username"
              name="username"
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              fullWidth
            />
            
            <Input
              label="Password"
              id="password"
              name="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              fullWidth
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="text-sm">
              <a href="#" className="font-medium text-blue-800 hover:text-blue-700">
                Forgot your password?
              </a>
            </div>
          </div>

          <div>
            <Button
              type="submit"
              variant="primary"
              fullWidth
              isLoading={isLoading}
            >
              Sign in
            </Button>
          </div>
        </form>
        
        <div className="mt-4 text-center text-sm text-gray-600">
          <p>Demo Accounts:</p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            <div 
              className="px-3 py-2 bg-gray-50 rounded border border-gray-200 cursor-pointer hover:bg-gray-100"
              onClick={() => setUsername('admin')}
            >
              <div className="font-medium">Admin</div>
              <div className="text-xs">admin</div>
            </div>
            <div 
              className="px-3 py-2 bg-gray-50 rounded border border-gray-200 cursor-pointer hover:bg-gray-100"
              onClick={() => setUsername('thompson')}
            >
              <div className="font-medium">Teacher</div>
              <div className="text-xs">thompson</div>
            </div>
            <div 
              className="px-3 py-2 bg-gray-50 rounded border border-gray-200 cursor-pointer hover:bg-gray-100"
              onClick={() => setUsername('jdoe')}
            >
              <div className="font-medium">Student</div>
              <div className="text-xs">jdoe</div>
            </div>
          </div>
          <p className="mt-2 text-xs text-gray-500">
            (Any password will work for this demo)
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;