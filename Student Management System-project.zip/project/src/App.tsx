import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/layout/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';

// Define a simple router
const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [currentPath, setCurrentPath] = React.useState(window.location.pathname);

  React.useEffect(() => {
    const handlePathChange = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handlePathChange);

    return () => {
      window.removeEventListener('popstate', handlePathChange);
    };
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
  };

  // Override links to use our navigate function
  React.useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      if (anchor && anchor.getAttribute('href')?.startsWith('/')) {
        e.preventDefault();
        navigate(anchor.getAttribute('href') || '/');
      }
    };

    document.addEventListener('click', handleClick);
    
    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, []);

  // If not authenticated, show login page
  if (!isAuthenticated) {
    return <Login />;
  }

  // Define routes
  let content;
  switch (currentPath) {
    case '/students':
      content = <Students />;
      break;
    case '/courses':
    case '/grades':
    case '/attendance':
    case '/reports':
    case '/notifications':
    case '/settings':
      content = (
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-4">This page is under development</h2>
          <p className="text-gray-600 mb-4">The {currentPath.substring(1)} page will be available soon.</p>
          <a href="/" className="text-blue-600 hover:underline">Return to Dashboard</a>
        </div>
      );
      break;
    default:
      content = <Dashboard />;
  }

  return (
    <Layout>
      {content}
    </Layout>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;