import React from 'react';
import Card from '../ui/Card';
import { grades } from '../../data/mockData';

const GradeDistribution: React.FC = () => {
  // Calculate grade distribution
  const totalGrades = grades.length;
  
  // Convert to percentages and categorize
  const gradesPercentages = grades.map(grade => 
    Math.round((grade.score / grade.maxScore) * 100)
  );
  
  // Define grade ranges
  const ranges = [
    { label: 'A (90-100%)', min: 90, max: 100, color: 'bg-green-500' },
    { label: 'B (80-89%)', min: 80, max: 89, color: 'bg-blue-500' },
    { label: 'C (70-79%)', min: 70, max: 79, color: 'bg-yellow-500' },
    { label: 'D (60-69%)', min: 60, max: 69, color: 'bg-orange-500' },
    { label: 'F (0-59%)', min: 0, max: 59, color: 'bg-red-500' }
  ];
  
  // Count grades in each range
  const distribution = ranges.map(range => {
    const count = gradesPercentages.filter(
      percentage => percentage >= range.min && percentage <= range.max
    ).length;
    const percentage = Math.round((count / totalGrades) * 100);
    return { ...range, count, percentage };
  });

  // Calculate average grade
  const averageGrade = 
    gradesPercentages.reduce((sum, percentage) => sum + percentage, 0) / totalGrades;

  return (
    <Card className="h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Grade Distribution</h3>
      </div>
      
      <div className="mt-6">
        {distribution.map((item, index) => (
          <div key={index} className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${item.color} mr-2`}></div>
                <span className="text-sm font-medium text-gray-700">{item.label}</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">{item.count} ({item.percentage}%)</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className={`h-2.5 rounded-full ${item.color} transition-all duration-1000 ease-out`} 
                style={{ width: `${item.percentage}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 bg-blue-50 p-3 rounded-lg border border-blue-100">
        <div className="text-2xl font-bold text-blue-700">{Math.round(averageGrade)}%</div>
        <div className="text-sm text-blue-600">Average Grade</div>
      </div>
    </Card>
  );
};

export default GradeDistribution;