import React from 'react';
import Card from '../ui/Card';
import { attendance } from '../../data/mockData';

const AttendanceChart: React.FC = () => {
  // Calculate attendance statistics
  const totalRecords = attendance.length;
  const presentCount = attendance.filter(a => a.status === 'present').length;
  const absentCount = attendance.filter(a => a.status === 'absent').length;
  const lateCount = attendance.filter(a => a.status === 'late').length;
  const excusedCount = attendance.filter(a => a.status === 'excused').length;
  
  const presentPercentage = Math.round((presentCount / totalRecords) * 100);
  const absentPercentage = Math.round((absentCount / totalRecords) * 100);
  const latePercentage = Math.round((lateCount / totalRecords) * 100);
  const excusedPercentage = Math.round((excusedCount / totalRecords) * 100);

  const chartData = [
    { label: 'Present', value: presentPercentage, color: 'bg-green-500' },
    { label: 'Absent', value: absentPercentage, color: 'bg-red-500' },
    { label: 'Late', value: latePercentage, color: 'bg-yellow-500' },
    { label: 'Excused', value: excusedPercentage, color: 'bg-gray-400' }
  ];

  return (
    <Card className="h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Attendance Overview</h3>
      </div>
      
      <div className="mt-6">
        {chartData.map((item, index) => (
          <div key={index} className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${item.color} mr-2`}></div>
                <span className="text-sm font-medium text-gray-700">{item.label}</span>
              </div>
              <span className="text-sm font-semibold text-gray-900">{item.value}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className={`h-2.5 rounded-full ${item.color} transition-all duration-1000 ease-out`} 
                style={{ width: `${item.value}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="bg-green-50 p-3 rounded-lg border border-green-100">
          <div className="text-2xl font-bold text-green-700">{presentPercentage}%</div>
          <div className="text-sm text-green-600">Attendance Rate</div>
        </div>
        <div className="bg-red-50 p-3 rounded-lg border border-red-100">
          <div className="text-2xl font-bold text-red-700">{absentPercentage}%</div>
          <div className="text-sm text-red-600">Absence Rate</div>
        </div>
      </div>
    </Card>
  );
};

export default AttendanceChart;