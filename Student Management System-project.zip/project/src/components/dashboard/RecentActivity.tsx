import React from 'react';
import Card from '../ui/Card';
import { grades, attendance, students, courses } from '../../data/mockData';

const RecentActivity: React.FC = () => {
  // Create a merged activity feed
  const activities = [
    ...grades.map(grade => ({
      type: 'grade',
      date: new Date(grade.date),
      data: grade,
      studentId: grade.studentId,
      courseId: grade.courseId
    })),
    ...attendance.map(record => ({
      type: 'attendance',
      date: new Date(record.date),
      data: record,
      studentId: record.studentId,
      courseId: record.courseId
    }))
  ];

  // Sort by date (most recent first)
  activities.sort((a, b) => b.date.getTime() - a.date.getTime());

  // Take only the 10 most recent activities
  const recentActivities = activities.slice(0, 10);

  const getStudentName = (studentId: string) => {
    const student = students.find(s => s.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : 'Unknown Student';
  };

  const getCourseName = (courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    return course ? course.name : 'Unknown Course';
  };

  const getActivityIcon = (type: string, data: any) => {
    if (type === 'grade') {
      return (
        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
          <span className="text-sm font-bold">{Math.round((data.score / data.maxScore) * 100)}%</span>
        </div>
      );
    } else if (type === 'attendance') {
      const statusColors = {
        present: 'bg-green-100 text-green-600',
        absent: 'bg-red-100 text-red-600',
        late: 'bg-yellow-100 text-yellow-600',
        excused: 'bg-gray-100 text-gray-600'
      };
      
      const color = statusColors[data.status as keyof typeof statusColors];
      
      return (
        <div className={`h-8 w-8 rounded-full ${color} flex items-center justify-center`}>
          {data.status === 'present' && <span>P</span>}
          {data.status === 'absent' && <span>A</span>}
          {data.status === 'late' && <span>L</span>}
          {data.status === 'excused' && <span>E</span>}
        </div>
      );
    }
    
    return null;
  };

  const getActivityDescription = (activity: any) => {
    const studentName = getStudentName(activity.studentId);
    const courseName = getCourseName(activity.courseId);
    
    if (activity.type === 'grade') {
      return (
        <>
          <span className="font-medium">{studentName}</span> received a grade of{' '}
          <span className="font-medium">{activity.data.score}/{activity.data.maxScore}</span> on{' '}
          <span className="font-medium">{activity.data.assignment}</span> in{' '}
          <span className="font-medium">{courseName}</span>
        </>
      );
    } else if (activity.type === 'attendance') {
      return (
        <>
          <span className="font-medium">{studentName}</span> was marked{' '}
          <span className="font-medium">{activity.data.status}</span> in{' '}
          <span className="font-medium">{courseName}</span>
        </>
      );
    }
    
    return null;
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <Card className="h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
      </div>
      
      <div className="space-y-4">
        {recentActivities.map((activity, index) => (
          <div key={index} className="flex space-x-3">
            {getActivityIcon(activity.type, activity.data)}
            
            <div className="flex-1 space-y-1">
              <p className="text-sm text-gray-800">
                {getActivityDescription(activity)}
              </p>
              <p className="text-xs text-gray-500">
                {formatDate(activity.date)}
              </p>
            </div>
          </div>
        ))}
        
        {recentActivities.length === 0 && (
          <p className="text-sm text-gray-500">No recent activities</p>
        )}
      </div>
      
      <div className="mt-4 text-center">
        <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
          View all activity
        </button>
      </div>
    </Card>
  );
};

export default RecentActivity;