import React from 'react';
import { 
  Users, BookOpen, GraduationCap, Calendar, BarChart3, 
  Settings, X, Home, Bell 
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const { user } = useAuth();
  
  const navigation = [
    { name: 'Dashboard', icon: Home, href: '/' },
    { name: 'Students', icon: Users, href: '/students' },
    { name: 'Courses', icon: BookOpen, href: '/courses' },
    { name: 'Grades', icon: GraduationCap, href: '/grades' },
    { name: 'Attendance', icon: Calendar, href: '/attendance' },
    { name: 'Reports', icon: BarChart3, href: '/reports' },
    { name: 'Notifications', icon: Bell, href: '/notifications' },
  ];

  // Admin only menu items
  const adminItems = [
    { name: 'Settings', icon: Settings, href: '/settings' },
  ];

  return (
    <>
      {/* Mobile sidebar overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-blue-900 text-white transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 transition-transform duration-300 ease-in-out md:static md:inset-auto md:z-auto`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-blue-800">
          <div className="flex items-center">
            <GraduationCap className="h-8 w-8 text-white" />
            <span className="ml-2 text-xl font-bold">SMS</span>
          </div>
          <button 
            className="md:hidden text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="px-2 py-4">
          <div className="px-2 mb-6">
            <div className="flex items-center space-x-3 mb-2">
              <div className="h-10 w-10 rounded-full bg-blue-700 flex items-center justify-center text-white uppercase">
                {user?.firstName.charAt(0)}{user?.lastName.charAt(0)}
              </div>
              <div>
                <div className="text-sm font-medium text-white">{user?.firstName} {user?.lastName}</div>
                <div className="text-xs text-blue-300 capitalize">{user?.role}</div>
              </div>
            </div>
          </div>
          
          <nav className="space-y-1">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-blue-100 hover:text-white hover:bg-blue-800 transition-colors duration-150"
              >
                <item.icon className="mr-4 h-5 w-5 text-blue-300 group-hover:text-blue-100" />
                {item.name}
              </a>
            ))}
            
            {user?.role === 'admin' && (
              <>
                <div className="border-t border-blue-800 my-4 pt-4">
                  <p className="px-3 text-xs font-semibold text-blue-400 uppercase tracking-wider">
                    Admin
                  </p>
                  {adminItems.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-blue-100 hover:text-white hover:bg-blue-800 transition-colors duration-150"
                    >
                      <item.icon className="mr-4 h-5 w-5 text-blue-300 group-hover:text-blue-100" />
                      {item.name}
                    </a>
                  ))}
                </div>
              </>
            )}
          </nav>
        </div>
      </div>
    </>
  );
};

export default Sidebar;